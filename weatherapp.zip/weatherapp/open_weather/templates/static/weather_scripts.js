// JavaScript source code
// variables definitions
const user_page = document.querySelector('user_page');
const enter = document.querySelector('.town_search button');
const clouds = document.querySelector('.weather-check');
const condition = document.querySelector('.weather_conditions');

search.addEventListener('click', () => {
	//define key and city
	// put in your own key for it to work
	const key = '';
	const city = document.querySelector('.town_search input').value;
	// loop through outcome
	if (city=='') return;
	fetch('https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${key}').then(response=>response.json()).then(json => {
			
		if (json.cod==401){
			return "key is invalid";
		};
		if (json.cod=='404'){
			return "Oops there's is a problem'";
		};

		const temp = document.querySelector('.weather-check .temp');
		const description = document.querySelector('.weather-check .describe_weather');
		const humid = document.querySelector('.weather_conditions .humidity span');
		const wind = document.querySelector('.weather_conditions .wind span');

		temp.innerHTML = `${parseInt(json.main.temp)}`;
		description.innerHTML = `${json.weather[0].description}`;
		humid.innerHTML = `${json.main.humidity}%`;
		wind.innerHTML = `${json.wind.speed}Km/hr`;
	});
});
