from django.shortcuts import render
from django.http import HttpResponse

Template_Dirs = (
    'os.path.join(BASE_DIR, templates),'
)

# Create your views here.
def index(request):
    return render(request, 'weather_page.html')
